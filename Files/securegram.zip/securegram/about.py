def text_author():
    data = "Автор: Ильченко Михаил Александрович\nГруппа: СО251КОБ\n"
    return data


def text_about():
    data = "Вконтакте: https://vk.com/mikhail27rus\nЯзык программирования: Python"
    return data


def text_program():
    data = "Добро пожаловать в Securegram!\n\nЭта программа предназначена для безопасного обмена сообщениями."
    return data
